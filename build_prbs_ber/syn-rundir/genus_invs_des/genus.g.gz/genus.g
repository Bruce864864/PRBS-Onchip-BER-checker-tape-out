######################################################################

# Created by Genus(TM) Synthesis Solution 21.19-s055_1 on Sat Apr 11 11:58:42 PDT 2026

# This file contains the Genus script for design:prbs_ber_top

######################################################################

set_db -quiet hdl_unconnected_value none
set_db -quiet design_mode_process 230.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet lp_insert_clock_gating true
set_db -quiet runtime_by_stage {{PBS_Generic-Start 0 20 0.0 29.0} {to_generic 4 24 3 32} {first_condense 1 25 0 33} {PBS_Generic_Opt-Post 5 25 4.737572 33.737572} {{PBS_Generic-Postgen HBO Optimizations} 0 25 0.0 33.737572} {PBS_TechMap-Start 0 27 0.0 34.737572} {{PBS_TechMap-Premap HBO Optimizations} 0 27 0.0 34.737572} {second_condense 0 27 0 36} {reify 2 29 2 38} {global_incr_map 0 29 0 38} {{PBS_Techmap-Global Mapping} 2 29 3.0398580000000024 37.77743} {{PBS_TechMap-Datapath Postmap Operations} 1 30 0.9973799999999997 38.77481} {{PBS_TechMap-Postmap HBO Optimizations} 0 30 -0.003378000000004988 38.771432} {{PBS_TechMap-Postmap Clock Gating} 0 30 0.0 38.771432} {{PBS_TechMap-Postmap Cleanup} 1 31 0.9968430000000055 39.768275} {PBS_Techmap-Post_MBCI 0 31 0.0 39.768275}}
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet hdl_error_on_blackbox true
set_db -quiet tinfo_tstamp_file .rs_liyuyao864.tstamp
set_db -quiet metric_enable true
set_db -quiet max_cpus_per_server 4
set_db -quiet lp_clock_gating_prefix CLKGATE
set_db -quiet lp_clock_gating_hierarchical true
set_db -quiet lp_insert_clock_gating_incremental true
set_db -quiet lp_clock_gating_register_aware true
set_db -quiet use_area_from_lef true
set_db -quiet flow_metrics_snapshot_uuid dc4e348a-bb4b-434f-9781-4ac0b95b06bf
set_db -quiet read_qrc_tech_file_rc_corner true
set_db -quiet auto_ungroup none
set_db -quiet use_tiehilo_for_const duplicate
if {[vfind design:prbs_ber_top -mode WCCOM.setup_view] eq ""} {
 create_mode -name WCCOM.setup_view -design design:prbs_ber_top 
}
set_db -quiet phys_use_segment_parasitics true
set_db -quiet probabilistic_extraction true
set_db -quiet ple_correlation_factors {1.9000 2.0000}
set_db -quiet maximum_interval_of_vias inf
set_db -quiet layer_aware_buffer true
set_db -quiet ple_mode global
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GAN2D1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GAN2D2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GAOI21D1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GAOI21D2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GAOI22D1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GBUFFD1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GBUFFD2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GBUFFD3BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GBUFFD8BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GDCAP10BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GDCAP2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GDCAP3BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GDCAP4BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GDCAPBWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GDFCNQD1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GDFQD1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GFILL10BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GFILL2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GFILL3BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GFILL4BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GFILLBWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GINVD1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GINVD2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GINVD3BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GINVD8BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GMUX2D1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GMUX2D2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GMUX2ND1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GMUX2ND2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GND2D1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GND2D2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GND2D3BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GND3D1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GND3D2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GNR2D1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GNR2D2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GNR3D1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GNR3D2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GOAI21D1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GOAI21D2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GOR2D1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GOR2D2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GSDFCNQD1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GTIEHBWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GTIELBWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GXNR2D1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GXNR2D2BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GXOR2D1BWP7T .avoid true
set_db -quiet lib_cell:WCCOM.setup_set/tcb018gbwp7twc_ccs/GXOR2D2BWP7T .avoid true
set_db -quiet library_domain:WCCOM.setup_cond .wireload_selection wireload_selection:WCCOM.setup_set/tcb018gbwp7twc_ccs/WireAreaForZero
set_db -quiet operating_condition:WCCOM.setup_set/tcb018gbwp7twc_ccs/WCCOM .tree_type balanced_tree
set_db -quiet operating_condition:WCCOM.setup_set/tcb018gbwp7twc_ccs/_nominal_ .tree_type balanced_tree
set_db -quiet operating_condition:WCCOM.setup_set/tpd018nvwc/WCCOM .tree_type worst_case_tree
set_db -quiet operating_condition:WCCOM.setup_set/tpd018nvwc/_nominal_ .tree_type balanced_tree
# BEGIN MSV SECTION
# END MSV SECTION
define_clock -name clk -mode mode:prbs_ber_top/WCCOM.setup_view -domain domain_1 -period 4000.0 -divide_period 1 -rise 0 -divide_rise 1 -fall 1 -divide_fall 2 -remove -design design:prbs_ber_top port:prbs_ber_top/clk
define_cost_group -design design:prbs_ber_top -name cg_enable_group_clk
define_cost_group -design design:prbs_ber_top -name clk
external_delay -accumulate -input {0.0 no_value 0.0 no_value} -clock clock:prbs_ber_top/WCCOM.setup_view/clk -name create_clock_delay_domain_1_clk_R_0 port:prbs_ber_top/clk
set_db -quiet external_delay:prbs_ber_top/WCCOM.setup_view/create_clock_delay_domain_1_clk_R_0 .clock_network_latency_included true
external_delay -accumulate -input {no_value 0.0 no_value 0.0} -clock clock:prbs_ber_top/WCCOM.setup_view/clk -edge_fall -name create_clock_delay_domain_1_clk_F_0 port:prbs_ber_top/clk
set_db -quiet external_delay:prbs_ber_top/WCCOM.setup_view/create_clock_delay_domain_1_clk_F_0 .clock_network_latency_included true
path_group -paths [specify_paths -lenient -mode mode:prbs_ber_top/WCCOM.setup_view -to clock:prbs_ber_top/WCCOM.setup_view/clk]  -name clk -group cost_group:prbs_ber_top/clk -user_priority -1047552
path_group -paths [specify_paths -mode mode:prbs_ber_top/WCCOM.setup_view -through {hpin:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/CLKGATE_RC_CG_HIER_INST2/enable pin:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/CLKGATE_RC_CG_HIER_INST2/RC_CGIC_INST/E hpin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/CLKGATE_RC_CG_HIER_INST3/enable pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/CLKGATE_RC_CG_HIER_INST3/RC_CGIC_INST/E hpin:prbs_ber_top/CLKGATE_RC_CG_HIER_INST0/enable pin:prbs_ber_top/CLKGATE_RC_CG_HIER_INST0/RC_CGIC_INST/E hpin:prbs_ber_top/CLKGATE_RC_CG_HIER_INST1/enable pin:prbs_ber_top/CLKGATE_RC_CG_HIER_INST1/RC_CGIC_INST/E}]  -name cg_enable_group_clk -group cost_group:prbs_ber_top/cg_enable_group_clk
set_clock_groups_write_script -name "clock_groups_clk_to_others" -asynchronous -group clock:prbs_ber_top/WCCOM.setup_view/clk -mode mode:prbs_ber_top/WCCOM.setup_view
# BEGIN DFT SECTION
set_db -quiet dft_scan_style muxed_scan
set_db -quiet dft_scanbit_waveform_analysis false
# END DFT SECTION
set_db -quiet design:prbs_ber_top .seq_reason_deleted_internal {}
set_db -quiet design:prbs_ber_top .qos_by_stage {{to_generic {wns -11111111} {tns -111111111} {vep -111111111} {area 10502} {cell_count 461} {utilization  0.00} {runtime 4 24 3 32} }{first_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 11976} {cell_count 570} {utilization  0.00} {runtime 1 25 0 33} }{second_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 11976} {cell_count 570} {utilization  0.00} {runtime 0 27 0 36} }{reify {wns 864} {tns 0} {vep 0} {area 7913} {cell_count 318} {utilization  0.00} {runtime 2 29 2 38} }{global_incr_map {wns 360} {tns 0} {vep 0} {area 7705} {cell_count 316} {utilization  0.00} {runtime 0 29 0 38} }}
set_db -quiet design:prbs_ber_top .seq_mbci_coverage 0.0
set_db -quiet design:prbs_ber_top .hdl_user_name prbs_ber_top
set_db -quiet design:prbs_ber_top .hdl_filelist {{default -sv {SYNTHESIS} {/w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_core.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_ctrl.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_top.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_core.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_ctrl.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_top.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_gen_top.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_ber_top.sv} {} {}}}
set_db -quiet design:prbs_ber_top .verification_directory fv/prbs_ber_top
set_db -quiet design:prbs_ber_top .lp_clock_gating_min_flops 3
set_db -quiet design:prbs_ber_top .lp_clock_gating_max_flops inf
set_db -quiet design:prbs_ber_top .arch_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_ber_top.sv
set_db -quiet design:prbs_ber_top .entity_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_ber_top.sv
set_db -quiet port:prbs_ber_top/clk .original_name clk
set_db -quiet port:prbs_ber_top/rst_n .original_name rst_n
set_db -quiet port:prbs_ber_top/en .original_name en
set_db -quiet port:prbs_ber_top/clear_count .original_name clear_count
set_db -quiet port:prbs_ber_top/seed_load .original_name seed_load
set_db -quiet port:prbs_ber_top/mode_select .original_name mode_select
set_db -quiet {port:prbs_ber_top/seed_in[14]} .original_name {seed_in[14]}
set_db -quiet {port:prbs_ber_top/seed_in[13]} .original_name {seed_in[13]}
set_db -quiet {port:prbs_ber_top/seed_in[12]} .original_name {seed_in[12]}
set_db -quiet {port:prbs_ber_top/seed_in[11]} .original_name {seed_in[11]}
set_db -quiet {port:prbs_ber_top/seed_in[10]} .original_name {seed_in[10]}
set_db -quiet {port:prbs_ber_top/seed_in[9]} .original_name {seed_in[9]}
set_db -quiet {port:prbs_ber_top/seed_in[8]} .original_name {seed_in[8]}
set_db -quiet {port:prbs_ber_top/seed_in[7]} .original_name {seed_in[7]}
set_db -quiet {port:prbs_ber_top/seed_in[6]} .original_name {seed_in[6]}
set_db -quiet {port:prbs_ber_top/seed_in[5]} .original_name {seed_in[5]}
set_db -quiet {port:prbs_ber_top/seed_in[4]} .original_name {seed_in[4]}
set_db -quiet {port:prbs_ber_top/seed_in[3]} .original_name {seed_in[3]}
set_db -quiet {port:prbs_ber_top/seed_in[2]} .original_name {seed_in[2]}
set_db -quiet {port:prbs_ber_top/seed_in[1]} .original_name {seed_in[1]}
set_db -quiet {port:prbs_ber_top/seed_in[0]} .original_name {seed_in[0]}
set_db -quiet port:prbs_ber_top/input_select .original_name input_select
set_db -quiet port:prbs_ber_top/inject_error_enable .original_name inject_error_enable
set_db -quiet port:prbs_ber_top/ext_serial_in .original_name ext_serial_in
set_db -quiet port:prbs_ber_top/prbs_out .external_pin_cap_min 5.0
set_db -quiet port:prbs_ber_top/prbs_out .external_capacitance_max {5.0 5.0}
set_db -quiet port:prbs_ber_top/prbs_out .external_capacitance_min 5.0
set_db -quiet port:prbs_ber_top/prbs_out .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet port:prbs_ber_top/prbs_out .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet port:prbs_ber_top/prbs_out .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet port:prbs_ber_top/prbs_out .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet port:prbs_ber_top/prbs_out .original_name prbs_out
set_db -quiet port:prbs_ber_top/prbs_out .external_pin_cap {5.0 5.0}
set_db -quiet port:prbs_ber_top/checker_in .external_pin_cap_min 5.0
set_db -quiet port:prbs_ber_top/checker_in .external_capacitance_max {5.0 5.0}
set_db -quiet port:prbs_ber_top/checker_in .external_capacitance_min 5.0
set_db -quiet port:prbs_ber_top/checker_in .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet port:prbs_ber_top/checker_in .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet port:prbs_ber_top/checker_in .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet port:prbs_ber_top/checker_in .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet port:prbs_ber_top/checker_in .original_name checker_in
set_db -quiet port:prbs_ber_top/checker_in .external_pin_cap {5.0 5.0}
set_db -quiet port:prbs_ber_top/checker_in_final .external_pin_cap_min 5.0
set_db -quiet port:prbs_ber_top/checker_in_final .external_capacitance_max {5.0 5.0}
set_db -quiet port:prbs_ber_top/checker_in_final .external_capacitance_min 5.0
set_db -quiet port:prbs_ber_top/checker_in_final .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet port:prbs_ber_top/checker_in_final .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet port:prbs_ber_top/checker_in_final .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet port:prbs_ber_top/checker_in_final .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet port:prbs_ber_top/checker_in_final .original_name checker_in_final
set_db -quiet port:prbs_ber_top/checker_in_final .external_pin_cap {5.0 5.0}
set_db -quiet port:prbs_ber_top/ref_bit .external_pin_cap_min 5.0
set_db -quiet port:prbs_ber_top/ref_bit .external_capacitance_max {5.0 5.0}
set_db -quiet port:prbs_ber_top/ref_bit .external_capacitance_min 5.0
set_db -quiet port:prbs_ber_top/ref_bit .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet port:prbs_ber_top/ref_bit .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet port:prbs_ber_top/ref_bit .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet port:prbs_ber_top/ref_bit .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet port:prbs_ber_top/ref_bit .original_name ref_bit
set_db -quiet port:prbs_ber_top/ref_bit .external_pin_cap {5.0 5.0}
set_db -quiet port:prbs_ber_top/bit_error .external_pin_cap_min 5.0
set_db -quiet port:prbs_ber_top/bit_error .external_capacitance_max {5.0 5.0}
set_db -quiet port:prbs_ber_top/bit_error .external_capacitance_min 5.0
set_db -quiet port:prbs_ber_top/bit_error .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet port:prbs_ber_top/bit_error .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet port:prbs_ber_top/bit_error .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet port:prbs_ber_top/bit_error .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet port:prbs_ber_top/bit_error .original_name bit_error
set_db -quiet port:prbs_ber_top/bit_error .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[31]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[31]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[31]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[31]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[31]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[31]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[31]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[31]} .original_name {error_count[31]}
set_db -quiet {port:prbs_ber_top/error_count[31]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[30]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[30]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[30]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[30]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[30]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[30]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[30]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[30]} .original_name {error_count[30]}
set_db -quiet {port:prbs_ber_top/error_count[30]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[29]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[29]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[29]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[29]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[29]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[29]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[29]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[29]} .original_name {error_count[29]}
set_db -quiet {port:prbs_ber_top/error_count[29]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[28]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[28]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[28]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[28]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[28]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[28]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[28]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[28]} .original_name {error_count[28]}
set_db -quiet {port:prbs_ber_top/error_count[28]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[27]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[27]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[27]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[27]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[27]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[27]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[27]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[27]} .original_name {error_count[27]}
set_db -quiet {port:prbs_ber_top/error_count[27]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[26]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[26]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[26]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[26]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[26]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[26]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[26]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[26]} .original_name {error_count[26]}
set_db -quiet {port:prbs_ber_top/error_count[26]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[25]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[25]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[25]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[25]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[25]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[25]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[25]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[25]} .original_name {error_count[25]}
set_db -quiet {port:prbs_ber_top/error_count[25]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[24]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[24]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[24]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[24]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[24]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[24]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[24]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[24]} .original_name {error_count[24]}
set_db -quiet {port:prbs_ber_top/error_count[24]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[23]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[23]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[23]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[23]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[23]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[23]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[23]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[23]} .original_name {error_count[23]}
set_db -quiet {port:prbs_ber_top/error_count[23]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[22]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[22]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[22]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[22]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[22]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[22]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[22]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[22]} .original_name {error_count[22]}
set_db -quiet {port:prbs_ber_top/error_count[22]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[21]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[21]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[21]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[21]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[21]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[21]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[21]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[21]} .original_name {error_count[21]}
set_db -quiet {port:prbs_ber_top/error_count[21]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[20]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[20]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[20]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[20]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[20]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[20]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[20]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[20]} .original_name {error_count[20]}
set_db -quiet {port:prbs_ber_top/error_count[20]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[19]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[19]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[19]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[19]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[19]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[19]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[19]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[19]} .original_name {error_count[19]}
set_db -quiet {port:prbs_ber_top/error_count[19]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[18]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[18]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[18]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[18]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[18]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[18]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[18]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[18]} .original_name {error_count[18]}
set_db -quiet {port:prbs_ber_top/error_count[18]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[17]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[17]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[17]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[17]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[17]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[17]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[17]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[17]} .original_name {error_count[17]}
set_db -quiet {port:prbs_ber_top/error_count[17]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[16]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[16]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[16]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[16]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[16]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[16]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[16]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[16]} .original_name {error_count[16]}
set_db -quiet {port:prbs_ber_top/error_count[16]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[15]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[15]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[15]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[15]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[15]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[15]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[15]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[15]} .original_name {error_count[15]}
set_db -quiet {port:prbs_ber_top/error_count[15]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[14]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[14]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[14]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[14]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[14]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[14]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[14]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[14]} .original_name {error_count[14]}
set_db -quiet {port:prbs_ber_top/error_count[14]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[13]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[13]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[13]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[13]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[13]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[13]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[13]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[13]} .original_name {error_count[13]}
set_db -quiet {port:prbs_ber_top/error_count[13]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[12]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[12]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[12]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[12]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[12]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[12]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[12]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[12]} .original_name {error_count[12]}
set_db -quiet {port:prbs_ber_top/error_count[12]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[11]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[11]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[11]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[11]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[11]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[11]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[11]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[11]} .original_name {error_count[11]}
set_db -quiet {port:prbs_ber_top/error_count[11]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[10]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[10]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[10]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[10]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[10]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[10]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[10]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[10]} .original_name {error_count[10]}
set_db -quiet {port:prbs_ber_top/error_count[10]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[9]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[9]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[9]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[9]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[9]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[9]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[9]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[9]} .original_name {error_count[9]}
set_db -quiet {port:prbs_ber_top/error_count[9]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[8]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[8]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[8]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[8]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[8]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[8]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[8]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[8]} .original_name {error_count[8]}
set_db -quiet {port:prbs_ber_top/error_count[8]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[7]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[7]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[7]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[7]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[7]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[7]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[7]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[7]} .original_name {error_count[7]}
set_db -quiet {port:prbs_ber_top/error_count[7]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[6]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[6]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[6]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[6]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[6]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[6]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[6]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[6]} .original_name {error_count[6]}
set_db -quiet {port:prbs_ber_top/error_count[6]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[5]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[5]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[5]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[5]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[5]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[5]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[5]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[5]} .original_name {error_count[5]}
set_db -quiet {port:prbs_ber_top/error_count[5]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[4]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[4]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[4]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[4]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[4]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[4]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[4]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[4]} .original_name {error_count[4]}
set_db -quiet {port:prbs_ber_top/error_count[4]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[3]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[3]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[3]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[3]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[3]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[3]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[3]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[3]} .original_name {error_count[3]}
set_db -quiet {port:prbs_ber_top/error_count[3]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[2]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[2]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[2]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[2]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[2]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[2]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[2]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[2]} .original_name {error_count[2]}
set_db -quiet {port:prbs_ber_top/error_count[2]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[1]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[1]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[1]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[1]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[1]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[1]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[1]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[1]} .original_name {error_count[1]}
set_db -quiet {port:prbs_ber_top/error_count[1]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[0]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[0]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/error_count[0]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/error_count[0]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[0]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/error_count[0]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[0]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/error_count[0]} .original_name {error_count[0]}
set_db -quiet {port:prbs_ber_top/error_count[0]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[31]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[31]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[31]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[31]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[31]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[31]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[31]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[31]} .original_name {total_count[31]}
set_db -quiet {port:prbs_ber_top/total_count[31]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[30]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[30]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[30]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[30]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[30]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[30]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[30]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[30]} .original_name {total_count[30]}
set_db -quiet {port:prbs_ber_top/total_count[30]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[29]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[29]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[29]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[29]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[29]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[29]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[29]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[29]} .original_name {total_count[29]}
set_db -quiet {port:prbs_ber_top/total_count[29]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[28]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[28]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[28]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[28]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[28]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[28]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[28]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[28]} .original_name {total_count[28]}
set_db -quiet {port:prbs_ber_top/total_count[28]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[27]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[27]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[27]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[27]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[27]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[27]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[27]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[27]} .original_name {total_count[27]}
set_db -quiet {port:prbs_ber_top/total_count[27]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[26]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[26]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[26]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[26]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[26]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[26]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[26]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[26]} .original_name {total_count[26]}
set_db -quiet {port:prbs_ber_top/total_count[26]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[25]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[25]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[25]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[25]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[25]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[25]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[25]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[25]} .original_name {total_count[25]}
set_db -quiet {port:prbs_ber_top/total_count[25]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[24]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[24]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[24]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[24]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[24]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[24]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[24]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[24]} .original_name {total_count[24]}
set_db -quiet {port:prbs_ber_top/total_count[24]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[23]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[23]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[23]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[23]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[23]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[23]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[23]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[23]} .original_name {total_count[23]}
set_db -quiet {port:prbs_ber_top/total_count[23]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[22]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[22]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[22]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[22]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[22]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[22]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[22]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[22]} .original_name {total_count[22]}
set_db -quiet {port:prbs_ber_top/total_count[22]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[21]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[21]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[21]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[21]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[21]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[21]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[21]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[21]} .original_name {total_count[21]}
set_db -quiet {port:prbs_ber_top/total_count[21]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[20]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[20]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[20]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[20]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[20]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[20]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[20]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[20]} .original_name {total_count[20]}
set_db -quiet {port:prbs_ber_top/total_count[20]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[19]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[19]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[19]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[19]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[19]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[19]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[19]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[19]} .original_name {total_count[19]}
set_db -quiet {port:prbs_ber_top/total_count[19]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[18]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[18]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[18]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[18]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[18]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[18]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[18]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[18]} .original_name {total_count[18]}
set_db -quiet {port:prbs_ber_top/total_count[18]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[17]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[17]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[17]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[17]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[17]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[17]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[17]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[17]} .original_name {total_count[17]}
set_db -quiet {port:prbs_ber_top/total_count[17]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[16]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[16]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[16]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[16]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[16]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[16]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[16]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[16]} .original_name {total_count[16]}
set_db -quiet {port:prbs_ber_top/total_count[16]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[15]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[15]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[15]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[15]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[15]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[15]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[15]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[15]} .original_name {total_count[15]}
set_db -quiet {port:prbs_ber_top/total_count[15]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[14]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[14]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[14]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[14]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[14]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[14]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[14]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[14]} .original_name {total_count[14]}
set_db -quiet {port:prbs_ber_top/total_count[14]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[13]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[13]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[13]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[13]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[13]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[13]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[13]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[13]} .original_name {total_count[13]}
set_db -quiet {port:prbs_ber_top/total_count[13]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[12]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[12]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[12]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[12]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[12]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[12]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[12]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[12]} .original_name {total_count[12]}
set_db -quiet {port:prbs_ber_top/total_count[12]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[11]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[11]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[11]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[11]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[11]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[11]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[11]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[11]} .original_name {total_count[11]}
set_db -quiet {port:prbs_ber_top/total_count[11]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[10]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[10]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[10]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[10]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[10]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[10]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[10]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[10]} .original_name {total_count[10]}
set_db -quiet {port:prbs_ber_top/total_count[10]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[9]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[9]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[9]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[9]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[9]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[9]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[9]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[9]} .original_name {total_count[9]}
set_db -quiet {port:prbs_ber_top/total_count[9]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[8]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[8]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[8]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[8]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[8]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[8]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[8]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[8]} .original_name {total_count[8]}
set_db -quiet {port:prbs_ber_top/total_count[8]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[7]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[7]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[7]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[7]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[7]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[7]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[7]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[7]} .original_name {total_count[7]}
set_db -quiet {port:prbs_ber_top/total_count[7]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[6]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[6]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[6]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[6]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[6]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[6]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[6]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[6]} .original_name {total_count[6]}
set_db -quiet {port:prbs_ber_top/total_count[6]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[5]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[5]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[5]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[5]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[5]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[5]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[5]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[5]} .original_name {total_count[5]}
set_db -quiet {port:prbs_ber_top/total_count[5]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[4]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[4]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[4]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[4]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[4]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[4]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[4]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[4]} .original_name {total_count[4]}
set_db -quiet {port:prbs_ber_top/total_count[4]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[3]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[3]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[3]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[3]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[3]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[3]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[3]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[3]} .original_name {total_count[3]}
set_db -quiet {port:prbs_ber_top/total_count[3]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[2]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[2]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[2]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[2]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[2]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[2]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[2]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[2]} .original_name {total_count[2]}
set_db -quiet {port:prbs_ber_top/total_count[2]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[1]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[1]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[1]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[1]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[1]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[1]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[1]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[1]} .original_name {total_count[1]}
set_db -quiet {port:prbs_ber_top/total_count[1]} .external_pin_cap {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[0]} .external_pin_cap_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[0]} .external_capacitance_max {5.0 5.0}
set_db -quiet {port:prbs_ber_top/total_count[0]} .external_capacitance_min 5.0
set_db -quiet {port:prbs_ber_top/total_count[0]} .external_pin_cap_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[0]} .external_capacitance_min_by_mode {{mode:prbs_ber_top/WCCOM.setup_view 5.0}}
set_db -quiet {port:prbs_ber_top/total_count[0]} .external_pin_cap_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[0]} .external_capacitance_max_by_mode {{mode:prbs_ber_top/WCCOM.setup_view {5.0 5.0}}}
set_db -quiet {port:prbs_ber_top/total_count[0]} .original_name {total_count[0]}
set_db -quiet {port:prbs_ber_top/total_count[0]} .external_pin_cap {5.0 5.0}
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_mapped .logical_hier false
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_mapped .boundary_opto strict_no
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_mapped .lp_clock_gating_min_flops 3
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_mapped .lp_clock_gating_max_flops inf
set_db -quiet inst:prbs_ber_top/CLKGATE_RC_CG_HIER_INST0/RC_CGIC_INST .gint_phase_inversion false
set_db -quiet inst:prbs_ber_top/CLKGATE_RC_CG_HIER_INST0/RC_CGIC_INST .is_genus_clock_gate true
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_1_mapped .logical_hier false
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_1_mapped .boundary_opto strict_no
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_1_mapped .lp_clock_gating_min_flops 3
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_1_mapped .lp_clock_gating_max_flops inf
set_db -quiet inst:prbs_ber_top/CLKGATE_RC_CG_HIER_INST1/RC_CGIC_INST .gint_phase_inversion false
set_db -quiet inst:prbs_ber_top/CLKGATE_RC_CG_HIER_INST1/RC_CGIC_INST .is_genus_clock_gate true
set_db -quiet module:prbs_ber_top/prbs_gen_top_mapped .hdl_user_name prbs_gen_top
set_db -quiet module:prbs_ber_top/prbs_gen_top_mapped .hdl_filelist {{default -sv {SYNTHESIS} {/w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_core.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_ctrl.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_top.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_core.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_ctrl.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_top.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_gen_top.sv} {} {}}}
set_db -quiet module:prbs_ber_top/prbs_gen_top_mapped .lp_clock_gating_min_flops 3
set_db -quiet module:prbs_ber_top/prbs_gen_top_mapped .lp_clock_gating_max_flops inf
set_db -quiet module:prbs_ber_top/prbs_gen_top_mapped .arch_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_gen_top.sv
set_db -quiet module:prbs_ber_top/prbs_gen_top_mapped .entity_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_gen_top.sv
set_db -quiet module:prbs_ber_top/prbs_top_mapped .hdl_user_name prbs_top
set_db -quiet module:prbs_ber_top/prbs_top_mapped .hdl_filelist {{default -sv {SYNTHESIS} {/w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_core.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_ctrl.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_top.sv} {} {}}}
set_db -quiet module:prbs_ber_top/prbs_top_mapped .lp_clock_gating_min_flops 3
set_db -quiet module:prbs_ber_top/prbs_top_mapped .lp_clock_gating_max_flops inf
set_db -quiet module:prbs_ber_top/prbs_top_mapped .arch_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_top.sv
set_db -quiet module:prbs_ber_top/prbs_top_mapped .entity_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_top.sv
set_db -quiet module:prbs_ber_top/prbs_core_LFSR_W7_DEFAULT_SEED1_mapped .hdl_user_name prbs_core
set_db -quiet module:prbs_ber_top/prbs_core_LFSR_W7_DEFAULT_SEED1_mapped .hdl_filelist {{default -sv {SYNTHESIS} {/w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_core.sv} {} {}}}
set_db -quiet module:prbs_ber_top/prbs_core_LFSR_W7_DEFAULT_SEED1_mapped .lp_clock_gating_min_flops 3
set_db -quiet module:prbs_ber_top/prbs_core_LFSR_W7_DEFAULT_SEED1_mapped .lp_clock_gating_max_flops inf
set_db -quiet module:prbs_ber_top/prbs_core_LFSR_W7_DEFAULT_SEED1_mapped .arch_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_core.sv
set_db -quiet module:prbs_ber_top/prbs_core_LFSR_W7_DEFAULT_SEED1_mapped .entity_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_core.sv
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_2_mapped .logical_hier false
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_2_mapped .boundary_opto strict_no
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_2_mapped .lp_clock_gating_min_flops 3
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_2_mapped .lp_clock_gating_max_flops inf
set_db -quiet inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/CLKGATE_RC_CG_HIER_INST2/RC_CGIC_INST .gint_phase_inversion false
set_db -quiet inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/CLKGATE_RC_CG_HIER_INST2/RC_CGIC_INST .is_genus_clock_gate true
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[4]} .original_name {{u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[4]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[4]} .single_bit_orig_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[4]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[4]/Q} .original_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[4]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[3]} .original_name {{u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[3]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[3]} .single_bit_orig_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[3]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[3]/Q} .original_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[3]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[2]} .original_name {{u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[2]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[2]} .single_bit_orig_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[2]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[2]/Q} .original_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[2]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[1]} .original_name {{u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[1]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[1]} .single_bit_orig_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[1]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[1]/Q} .original_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[1]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[0]} .original_name {{u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[0]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[0]} .single_bit_orig_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[0]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[0]/Q} .original_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[0]/q}
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[0]/QN} .original_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[0]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[5]} .original_name {{u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[5]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[5]} .single_bit_orig_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[5]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[5]/Q} .original_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[5]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[6]} .original_name {{u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[6]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[6]} .single_bit_orig_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[6]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q_reg[6]/Q} .original_name {u_prbs_gen_top/u_prbs7_top/u_prbs_core/lfsr_q[6]/q}
set_db -quiet module:prbs_ber_top/prbs_ctrl_LFSR_W7_DEFAULT_SEED1_mapped .hdl_user_name prbs_ctrl
set_db -quiet module:prbs_ber_top/prbs_ctrl_LFSR_W7_DEFAULT_SEED1_mapped .hdl_filelist {{default -sv {SYNTHESIS} {/w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_ctrl.sv} {} {}}}
set_db -quiet module:prbs_ber_top/prbs_ctrl_LFSR_W7_DEFAULT_SEED1_mapped .lp_clock_gating_min_flops 3
set_db -quiet module:prbs_ber_top/prbs_ctrl_LFSR_W7_DEFAULT_SEED1_mapped .lp_clock_gating_max_flops inf
set_db -quiet module:prbs_ber_top/prbs_ctrl_LFSR_W7_DEFAULT_SEED1_mapped .arch_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_ctrl.sv
set_db -quiet module:prbs_ber_top/prbs_ctrl_LFSR_W7_DEFAULT_SEED1_mapped .entity_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs_ctrl.sv
set_db -quiet module:prbs_ber_top/prbs15_top_mapped .hdl_user_name prbs15_top
set_db -quiet module:prbs_ber_top/prbs15_top_mapped .hdl_filelist {{default -sv {SYNTHESIS} {/w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_core.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_ctrl.sv /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_top.sv} {} {}}}
set_db -quiet module:prbs_ber_top/prbs15_top_mapped .lp_clock_gating_min_flops 3
set_db -quiet module:prbs_ber_top/prbs15_top_mapped .lp_clock_gating_max_flops inf
set_db -quiet module:prbs_ber_top/prbs15_top_mapped .arch_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_top.sv
set_db -quiet module:prbs_ber_top/prbs15_top_mapped .entity_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_top.sv
set_db -quiet module:prbs_ber_top/prbs15_core_LFSR_W15_DEFAULT_SEED1_mapped .hdl_user_name prbs15_core
set_db -quiet module:prbs_ber_top/prbs15_core_LFSR_W15_DEFAULT_SEED1_mapped .hdl_filelist {{default -sv {SYNTHESIS} {/w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_core.sv} {} {}}}
set_db -quiet module:prbs_ber_top/prbs15_core_LFSR_W15_DEFAULT_SEED1_mapped .lp_clock_gating_min_flops 3
set_db -quiet module:prbs_ber_top/prbs15_core_LFSR_W15_DEFAULT_SEED1_mapped .lp_clock_gating_max_flops inf
set_db -quiet module:prbs_ber_top/prbs15_core_LFSR_W15_DEFAULT_SEED1_mapped .arch_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_core.sv
set_db -quiet module:prbs_ber_top/prbs15_core_LFSR_W15_DEFAULT_SEED1_mapped .entity_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_core.sv
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_3_mapped .logical_hier false
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_3_mapped .boundary_opto strict_no
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_3_mapped .lp_clock_gating_min_flops 3
set_db -quiet module:prbs_ber_top/CLKGATE_RC_CG_MOD_3_mapped .lp_clock_gating_max_flops inf
set_db -quiet inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/CLKGATE_RC_CG_HIER_INST3/RC_CGIC_INST .gint_phase_inversion false
set_db -quiet inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/CLKGATE_RC_CG_HIER_INST3/RC_CGIC_INST .is_genus_clock_gate true
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[12]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[12]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[12]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[12]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[12]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[12]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[11]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[11]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[11]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[11]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[11]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[11]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[10]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[10]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[10]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[10]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[10]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[10]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[9]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[9]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[9]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[9]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[9]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[9]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[8]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[8]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[8]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[8]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[8]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[8]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[7]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[7]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[7]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[7]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[7]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[7]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[6]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[6]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[6]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[6]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[6]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[6]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[5]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[5]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[5]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[5]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[5]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[5]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[4]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[4]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[4]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[4]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[4]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[4]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[3]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[3]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[3]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[3]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[3]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[3]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[2]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[2]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[2]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[2]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[2]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[2]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[1]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[1]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[1]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[1]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[1]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[1]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[0]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[0]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[0]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[0]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[0]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[0]/q}
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[0]/QN} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[0]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[13]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[13]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[13]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[13]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[13]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[13]/q}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[14]} .original_name {{u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[14]}}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[14]} .single_bit_orig_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[14]}
set_db -quiet {inst:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q_reg[14]/Q} .original_name {u_prbs_gen_top/u_prbs15_top/u_prbs15_core/lfsr_q[14]/q}
set_db -quiet module:prbs_ber_top/prbs15_ctrl_LFSR_W15_DEFAULT_SEED1_mapped .hdl_user_name prbs15_ctrl
set_db -quiet module:prbs_ber_top/prbs15_ctrl_LFSR_W15_DEFAULT_SEED1_mapped .hdl_filelist {{default -sv {SYNTHESIS} {/w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_ctrl.sv} {} {}}}
set_db -quiet module:prbs_ber_top/prbs15_ctrl_LFSR_W15_DEFAULT_SEED1_mapped .lp_clock_gating_min_flops 3
set_db -quiet module:prbs_ber_top/prbs15_ctrl_LFSR_W15_DEFAULT_SEED1_mapped .lp_clock_gating_max_flops inf
set_db -quiet module:prbs_ber_top/prbs15_ctrl_LFSR_W15_DEFAULT_SEED1_mapped .arch_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_ctrl.sv
set_db -quiet module:prbs_ber_top/prbs15_ctrl_LFSR_W15_DEFAULT_SEED1_mapped .entity_filename /w/home.09/home/liyuyao864/ee209/prbs_project/rtl/prbs15_ctrl.sv
set_db -quiet {inst:prbs_ber_top/error_count_reg[0]} .original_name {{error_count[0]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[0]} .single_bit_orig_name {error_count[0]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[0]/Q} .original_name {error_count[0]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[1]} .original_name {{error_count[1]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[1]} .single_bit_orig_name {error_count[1]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[1]/Q} .original_name {error_count[1]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[2]} .original_name {{error_count[2]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[2]} .single_bit_orig_name {error_count[2]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[2]/Q} .original_name {error_count[2]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[3]} .original_name {{error_count[3]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[3]} .single_bit_orig_name {error_count[3]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[3]/Q} .original_name {error_count[3]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[4]} .original_name {{error_count[4]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[4]} .single_bit_orig_name {error_count[4]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[4]/Q} .original_name {error_count[4]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[5]} .original_name {{error_count[5]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[5]} .single_bit_orig_name {error_count[5]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[5]/Q} .original_name {error_count[5]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[6]} .original_name {{error_count[6]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[6]} .single_bit_orig_name {error_count[6]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[6]/Q} .original_name {error_count[6]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[7]} .original_name {{error_count[7]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[7]} .single_bit_orig_name {error_count[7]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[7]/Q} .original_name {error_count[7]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[8]} .original_name {{error_count[8]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[8]} .single_bit_orig_name {error_count[8]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[8]/Q} .original_name {error_count[8]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[9]} .original_name {{error_count[9]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[9]} .single_bit_orig_name {error_count[9]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[9]/Q} .original_name {error_count[9]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[10]} .original_name {{error_count[10]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[10]} .single_bit_orig_name {error_count[10]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[10]/Q} .original_name {error_count[10]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[11]} .original_name {{error_count[11]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[11]} .single_bit_orig_name {error_count[11]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[11]/Q} .original_name {error_count[11]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[12]} .original_name {{error_count[12]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[12]} .single_bit_orig_name {error_count[12]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[12]/Q} .original_name {error_count[12]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[13]} .original_name {{error_count[13]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[13]} .single_bit_orig_name {error_count[13]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[13]/Q} .original_name {error_count[13]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[14]} .original_name {{error_count[14]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[14]} .single_bit_orig_name {error_count[14]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[14]/Q} .original_name {error_count[14]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[15]} .original_name {{error_count[15]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[15]} .single_bit_orig_name {error_count[15]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[15]/Q} .original_name {error_count[15]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[16]} .original_name {{error_count[16]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[16]} .single_bit_orig_name {error_count[16]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[16]/Q} .original_name {error_count[16]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[17]} .original_name {{error_count[17]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[17]} .single_bit_orig_name {error_count[17]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[17]/Q} .original_name {error_count[17]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[18]} .original_name {{error_count[18]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[18]} .single_bit_orig_name {error_count[18]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[18]/Q} .original_name {error_count[18]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[19]} .original_name {{error_count[19]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[19]} .single_bit_orig_name {error_count[19]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[19]/Q} .original_name {error_count[19]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[20]} .original_name {{error_count[20]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[20]} .single_bit_orig_name {error_count[20]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[20]/Q} .original_name {error_count[20]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[21]} .original_name {{error_count[21]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[21]} .single_bit_orig_name {error_count[21]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[21]/Q} .original_name {error_count[21]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[22]} .original_name {{error_count[22]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[22]} .single_bit_orig_name {error_count[22]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[22]/Q} .original_name {error_count[22]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[23]} .original_name {{error_count[23]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[23]} .single_bit_orig_name {error_count[23]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[23]/Q} .original_name {error_count[23]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[24]} .original_name {{error_count[24]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[24]} .single_bit_orig_name {error_count[24]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[24]/Q} .original_name {error_count[24]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[25]} .original_name {{error_count[25]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[25]} .single_bit_orig_name {error_count[25]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[25]/Q} .original_name {error_count[25]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[26]} .original_name {{error_count[26]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[26]} .single_bit_orig_name {error_count[26]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[26]/Q} .original_name {error_count[26]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[27]} .original_name {{error_count[27]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[27]} .single_bit_orig_name {error_count[27]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[27]/Q} .original_name {error_count[27]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[28]} .original_name {{error_count[28]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[28]} .single_bit_orig_name {error_count[28]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[28]/Q} .original_name {error_count[28]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[29]} .original_name {{error_count[29]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[29]} .single_bit_orig_name {error_count[29]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[29]/Q} .original_name {error_count[29]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[30]} .original_name {{error_count[30]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[30]} .single_bit_orig_name {error_count[30]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[30]/Q} .original_name {error_count[30]/q}
set_db -quiet {inst:prbs_ber_top/error_count_reg[31]} .original_name {{error_count[31]}}
set_db -quiet {inst:prbs_ber_top/error_count_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/error_count_reg[31]} .single_bit_orig_name {error_count[31]}
set_db -quiet {inst:prbs_ber_top/error_count_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/error_count_reg[31]/Q} .original_name {error_count[31]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[0]} .original_name {{total_count[0]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[0]} .single_bit_orig_name {total_count[0]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[0]/Q} .original_name {total_count[0]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[1]} .original_name {{total_count[1]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[1]} .single_bit_orig_name {total_count[1]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[1]/Q} .original_name {total_count[1]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[2]} .original_name {{total_count[2]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[2]} .single_bit_orig_name {total_count[2]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[2]/Q} .original_name {total_count[2]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[3]} .original_name {{total_count[3]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[3]} .single_bit_orig_name {total_count[3]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[3]/Q} .original_name {total_count[3]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[4]} .original_name {{total_count[4]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[4]} .single_bit_orig_name {total_count[4]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[4]/Q} .original_name {total_count[4]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[5]} .original_name {{total_count[5]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[5]} .single_bit_orig_name {total_count[5]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[5]/Q} .original_name {total_count[5]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[6]} .original_name {{total_count[6]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[6]} .single_bit_orig_name {total_count[6]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[6]/Q} .original_name {total_count[6]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[7]} .original_name {{total_count[7]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[7]} .single_bit_orig_name {total_count[7]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[7]/Q} .original_name {total_count[7]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[8]} .original_name {{total_count[8]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[8]} .single_bit_orig_name {total_count[8]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[8]/Q} .original_name {total_count[8]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[9]} .original_name {{total_count[9]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[9]} .single_bit_orig_name {total_count[9]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[9]/Q} .original_name {total_count[9]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[10]} .original_name {{total_count[10]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[10]} .single_bit_orig_name {total_count[10]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[10]/Q} .original_name {total_count[10]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[11]} .original_name {{total_count[11]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[11]} .single_bit_orig_name {total_count[11]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[11]/Q} .original_name {total_count[11]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[12]} .original_name {{total_count[12]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[12]} .single_bit_orig_name {total_count[12]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[12]/Q} .original_name {total_count[12]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[13]} .original_name {{total_count[13]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[13]} .single_bit_orig_name {total_count[13]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[13]/Q} .original_name {total_count[13]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[14]} .original_name {{total_count[14]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[14]} .single_bit_orig_name {total_count[14]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[14]/Q} .original_name {total_count[14]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[15]} .original_name {{total_count[15]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[15]} .single_bit_orig_name {total_count[15]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[15]/Q} .original_name {total_count[15]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[16]} .original_name {{total_count[16]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[16]} .single_bit_orig_name {total_count[16]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[16]/Q} .original_name {total_count[16]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[17]} .original_name {{total_count[17]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[17]} .single_bit_orig_name {total_count[17]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[17]/Q} .original_name {total_count[17]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[18]} .original_name {{total_count[18]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[18]} .single_bit_orig_name {total_count[18]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[18]/Q} .original_name {total_count[18]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[19]} .original_name {{total_count[19]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[19]} .single_bit_orig_name {total_count[19]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[19]/Q} .original_name {total_count[19]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[20]} .original_name {{total_count[20]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[20]} .single_bit_orig_name {total_count[20]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[20]/Q} .original_name {total_count[20]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[21]} .original_name {{total_count[21]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[21]} .single_bit_orig_name {total_count[21]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[21]/Q} .original_name {total_count[21]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[22]} .original_name {{total_count[22]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[22]} .single_bit_orig_name {total_count[22]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[22]/Q} .original_name {total_count[22]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[23]} .original_name {{total_count[23]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[23]} .single_bit_orig_name {total_count[23]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[23]/Q} .original_name {total_count[23]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[24]} .original_name {{total_count[24]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[24]} .single_bit_orig_name {total_count[24]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[24]/Q} .original_name {total_count[24]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[25]} .original_name {{total_count[25]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[25]} .single_bit_orig_name {total_count[25]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[25]/Q} .original_name {total_count[25]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[26]} .original_name {{total_count[26]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[26]} .single_bit_orig_name {total_count[26]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[26]/Q} .original_name {total_count[26]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[27]} .original_name {{total_count[27]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[27]} .single_bit_orig_name {total_count[27]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[27]/Q} .original_name {total_count[27]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[28]} .original_name {{total_count[28]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[28]} .single_bit_orig_name {total_count[28]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[28]/Q} .original_name {total_count[28]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[29]} .original_name {{total_count[29]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[29]} .single_bit_orig_name {total_count[29]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[29]/Q} .original_name {total_count[29]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[30]} .original_name {{total_count[30]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[30]} .single_bit_orig_name {total_count[30]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[30]/Q} .original_name {total_count[30]/q}
set_db -quiet {inst:prbs_ber_top/total_count_reg[31]} .original_name {{total_count[31]}}
set_db -quiet {inst:prbs_ber_top/total_count_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:prbs_ber_top/total_count_reg[31]} .single_bit_orig_name {total_count[31]}
set_db -quiet {inst:prbs_ber_top/total_count_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:prbs_ber_top/total_count_reg[31]/Q} .original_name {total_count[31]/q}
# BEGIN PMBIST SECTION
# END PMBIST SECTION
# BEGIN PHYSICAL ANNOTATION SECTION
# END PHYSICAL ANNOTATION SECTION
# BEGIN GLO TBR TABLE
set_db -quiet design:prbs_ber_top .set_boundary_change_new {start restore}
set_db -quiet design:prbs_ber_top .set_boundary_change_new {finish restore}
# END GLO TBR TABLE
set_db -quiet source_verbose true
#############################################################
#####   FLOW WRITE   ########################################
##
## Written by Genus(TM) Synthesis Solution version 21.19-s055_1
## flowkit v21.12-s019_1
## Written on 11:58:43 11-Apr 2026
#############################################################
#####   Flow Definitions   ##################################

#############################################################
#####   Step Definitions   ##################################


#############################################################
#####   Attribute Definitions   #############################

if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}


#############################################################
#####   Flow History   ######################################

if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}
if {[is_attribute flow_plugin_steps -obj_type root]} {set_db flow_plugin_steps {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_remark -obj_type root]} {set_db flow_remark {}}
if {[is_attribute flow_features -obj_type root]} {set_db flow_features {}}
if {[is_attribute flow_feature_values -obj_type root]} {set_db flow_feature_values {}}
if {[is_attribute flow_write_db_args -obj_type root]} {set_db flow_write_db_args {}}
if {[is_attribute flow_write_db_sdc -obj_type root]} {set_db flow_write_db_sdc true}
if {[is_attribute flow_write_db_common -obj_type root]} {set_db flow_write_db_common false}
if {[is_attribute flow_post_db_overwrite -obj_type root]} {set_db flow_post_db_overwrite {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_last -obj_type root]} {set_db flow_step_last {}}
if {[is_attribute flow_step_current -obj_type root]} {set_db flow_step_current {}}
if {[is_attribute flow_step_canonical_current -obj_type root]} {set_db flow_step_canonical_current {}}
if {[is_attribute flow_step_next -obj_type root]} {set_db flow_step_next {}}
if {[is_attribute flow_working_directory -obj_type root]} {set_db flow_working_directory .}
if {[is_attribute flow_branch -obj_type root]} {set_db flow_branch {}}
if {[is_attribute flow_caller_data -obj_type root]} {set_db flow_caller_data {}}
if {[is_attribute flow_metrics_snapshot_uuid -obj_type root]} {set_db flow_metrics_snapshot_uuid dc4e348a-bb4b-434f-9781-4ac0b95b06bf}
if {[is_attribute flow_starting_db -obj_type root]} {set_db flow_starting_db {}}
if {[is_attribute flow_db_directory -obj_type root]} {set_db flow_db_directory dbs}
if {[is_attribute flow_report_directory -obj_type root]} {set_db flow_report_directory reports}
if {[is_attribute flow_log_directory -obj_type root]} {set_db flow_log_directory logs}
if {[is_attribute flow_mail_to -obj_type root]} {set_db flow_mail_to {}}
if {[is_attribute flow_exit_when_done -obj_type root]} {set_db flow_exit_when_done false}
if {[is_attribute flow_mail_on_error -obj_type root]} {set_db flow_mail_on_error false}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_history -obj_type root]} {set_db flow_history {}}
if {[is_attribute flow_step_last_status -obj_type root]} {set_db flow_step_last_status not_run}
if {[is_attribute flow_step_last_msg -obj_type root]} {set_db flow_step_last_msg {}}
if {[is_attribute flow_run_tag -obj_type root]} {set_db flow_run_tag {}}
if {[is_attribute flow_current_cache -obj_type root]} {set_db flow_current_cache {}}
if {[is_attribute flow_step_order_cache -obj_type root]} {set_db flow_step_order_cache {}}
if {[is_attribute flow_step_results_cache -obj_type root]} {set_db flow_step_results_cache {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_execute_in_global -obj_type root]} {set_db flow_execute_in_global true}
if {[is_attribute flow_overwrite_db -obj_type root]} {set_db flow_overwrite_db false}
if {[is_attribute flow_print_run_information -obj_type root]} {set_db flow_print_run_information false}
if {[is_attribute flow_verbose -obj_type root]} {set_db flow_verbose true}
if {[is_attribute flow_print_run_information_full -obj_type root]} {set_db flow_print_run_information_full false}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_init_header_tcl -obj_type root]} {set_db flow_init_header_tcl {}}
if {[is_attribute flow_init_footer_tcl -obj_type root]} {set_db flow_init_footer_tcl {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_step_last_number -obj_type root]} {set_db flow_step_last_number 0}
if {[is_attribute flow_autoload_applets -obj_type root]} {set_db flow_autoload_applets false}
if {[is_attribute flow_autoload_dir -obj_type root]} {set_db flow_autoload_dir error}
if {[is_attribute flow_skip_auto_db_save -obj_type root]} {set_db flow_skip_auto_db_save true}
if {[is_attribute flow_skip_auto_generate_metrics -obj_type root]} {set_db flow_skip_auto_generate_metrics false}
if {[is_attribute flow_top -obj_type root]} {set_db flow_top {}}
if {[is_attribute flow_hier_path -obj_type root]} {set_db flow_hier_path {}}
if {[is_attribute flow_schedule -obj_type root]} {set_db flow_schedule {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_script -obj_type root]} {set_db flow_script {}}
if {[is_attribute flow_yaml_script -obj_type root]} {set_db flow_yaml_script {}}
if {[is_attribute flow_cla_enabled_features -obj_type root]} {set_db flow_cla_enabled_features {}}
if {[is_attribute flow_cla_inject_tcl -obj_type root]} {set_db flow_cla_inject_tcl {}}
if {[is_attribute flow_error_message -obj_type root]} {set_db flow_error_message {}}
if {[is_attribute flow_error_errorinfo -obj_type root]} {set_db flow_error_errorinfo {}}
if {[is_attribute flow_exclude_time_for_init_flow -obj_type root]} {set_db flow_exclude_time_for_init_flow false}
if {[is_attribute flow_error_write_db -obj_type root]} {set_db flow_error_write_db true}
if {[is_attribute flow_advanced_metric_isolation -obj_type root]} {set_db flow_advanced_metric_isolation flow}
if {[is_attribute flow_yaml_root -obj_type root]} {set_db flow_yaml_root {}}
if {[is_attribute flow_yaml_root_dir -obj_type root]} {set_db flow_yaml_root_dir {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}

#############################################################
#####   User Defined Attributes   ###########################

